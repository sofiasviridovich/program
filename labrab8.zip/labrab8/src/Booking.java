import java.util.Scanner;

class Booking extends Login {
    @Override
    public void arenda() {
        System.out.println("Заполните анкету:");
    }
    public String BookingDisplay() {
        Scanner in = new Scanner(System.in);
        String bookingNameInfo;

        do {
            System.out.println("Введите ваше имя: ");
            bookingNameInfo = in.next();

            if (!bookingNameInfo.matches("[a-zA-Z]+")) {
                System.out.println("Ошибка: Введите только текст без чисел и символов.");
            }
        } while (!bookingNameInfo.matches("[a-zA-Z]+"));

        return bookingNameInfo;
    }
    public String BookingInfoTime() {
        Scanner in = new Scanner(System.in);
        String bookingInfoTime;

        do {
            System.out.println("Введите срок на который хотите арендовать: ");
            bookingInfoTime = in.next();

            if (!bookingInfoTime.matches("\\d+")) {
                System.out.println("Ошибка: Введите только числа.");
            }
        } while (!bookingInfoTime.matches("\\d+"));

        return bookingInfoTime;
    }
    public String BookingPassportInfo() {
        System.out.println("Введите ваши паспортные данные: ");
        Scanner in = new Scanner(System.in);
        while (true) {
            try {
                int passportInfo = in.nextInt();
                if (passportInfo >= 0) {
                    return String.valueOf(passportInfo);
                } else {
                    System.out.println("Ошибка: Паспортные данные не могут быть отрицательными.");
                }
            } catch (Exception e) {
                System.out.println("Ошибка: Неверный формат ввода. Введите только числа.");
                in.next();
            }
        }
    }

    public String BookingCardInfo() {
        System.out.println("Введите реквизиты вашей карты: ");
        Scanner in = new Scanner(System.in);
        while (true) {
            try {
                int cardInfo = in.nextInt();
                if (cardInfo >= 0) {
                    return String.valueOf(cardInfo);
                } else {
                    System.out.println("Ошибка: Реквизиты карты не могут быть отрицательными.");
                }
            } catch (Exception e) {
                System.out.println("Ошибка: Неверный формат ввода. Введите только числа.");
                in.next();
            }
        }
    }
}
