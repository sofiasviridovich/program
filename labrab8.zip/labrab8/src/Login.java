public class Login extends Transport {

    public void arenda() {
        System.out.println("Какую машину вы хотите арендовать? ");
    }
}
