import java.util.*;
import java.util.Scanner;
import java.util.ArrayList;

public class Main {
    static List<Car> cars = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) throws MyException{
        int num;
        do {
            System.out.println("Зайти как 1.Администратор. 2.Пользователь. \nДля выхода из системы введите 0");
            try {
                num = scanner.nextInt();
                if (num < 0) {
                    throw new IllegalArgumentException("Введено отрицательное число");
                }
                switch (num) {
                    case 1: {
                        System.out.println("\nВы вошли как администратор");
                        Admin admin = new Admin();
                        admin.MainMenu(cars);
                        break;
                    }
                    case 2: {
                        System.out.println("\nВы вошли как пользователь");
                        Transport login = new Login();
                        login.arenda();
                        Admin admin1 = new Admin();
                        List<Car> cars = admin1.readFromFile();
                        if (cars.isEmpty()) {
                            System.out.println("Файл для чтения не существует.");
                            break;
                        }
                        String num1 = login.loginDisplay();
                        System.out.println("Отличный выбор!");

                        Booking booking = new Booking();
                        booking.arenda();
                        booking.BookingDisplay();
                        booking.BookingInfoTime();
                        booking.BookingCardInfo();
                        booking.BookingPassportInfo();
                        break;
                    }
                    case 0: {
                        System.out.println("Выход из программы...");
                        return;
                    }
                    default: {
                        throw new MyException("error");
                    }
                }
            } catch (InputMismatchException e) {
                System.out.println("Ошибка ввода данных. Пожалуйста, введите корректные данные.");
                scanner.nextLine();
                num = 2;
            } catch (Exception e) {
                System.out.println("Ошибка ввода данных. Пожалуйста, введите корректные данные.");
                scanner.nextLine();
                num = 2;
            }
        } while (num != 0);
    }
}