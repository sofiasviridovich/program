import java.util.*;
import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Admin implements Serializable{
    private static Scanner scanner = new Scanner(System.in);
    public void writeToFile(List<Car> cars) {
        try {
            FileOutputStream fileOut = new FileOutputStream("listOfCars.txt");
            ObjectOutputStream objectOut = new ObjectOutputStream(fileOut);
            objectOut.writeObject(cars);
            objectOut.close();
            fileOut.close();
            System.out.println("Cars successfully written to the file listOfCars.txt");
        } catch (IOException e) {
            System.out.println("Error writing to the file: " + e.getMessage());
        }
    }

    public List<Car> readFromFile() {
        List<Car> cars = new ArrayList<>();
        try {
            FileInputStream fileIn = new FileInputStream("listOfCars.txt");
            ObjectInputStream objectIn = new ObjectInputStream(fileIn);
            cars = (List<Car>) objectIn.readObject();
            objectIn.close();
            fileIn.close();
            System.out.println("Cars read from the file:");
            for (Car car : cars) {
                System.out.println(car.toString());
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error reading from the file: " + e.getMessage());
        }
        return cars;
    }

    public void MainMenu( List<Car> cars) {
        try {
            System.out.println("1.Подтвердить заявку  2.Отклонить заявку 3. Добавить машины 4. Запись в файл 5. Чтение из файла");
            int num;
            while (true) {
                try {
                    num = scanner.nextInt();
                    if (num >= 1 && num <= 5) {
                        break;
                    } else {
                        System.out.println("Ошибка ввода. Введите число от 1 до 5.");
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Ошибка ввода. Введите целое число.");
                    scanner.nextLine();
                }
            }
            switch (num) {
                case 2:
                    System.out.println("Заявка отменена. Укажите причину:");
                    scanner.nextLine();
                    String rejectionReason = "";
                    while (true) {
                        try {
                            rejectionReason = scanner.nextLine();
                            if (rejectionReason.matches("[a-zA-Z]+")) {
                                break;
                            } else {
                                System.out.println("Ошибка ввода. Причина должна содержать только буквы.");
                            }
                        } catch (InputMismatchException e) {
                            System.out.println("Ошибка ввода. Введите причину отклонения заявки:");
                            scanner.nextLine();
                        }
                    }
                    System.out.println("\nОтвет отправлен");
                    break;
                case 3:
                    AddInfo(cars);
                    break;
                case 4:
                    writeToFile(cars);
                    break;
                case 5:
                    cars=readFromFile();
                    break;
            }

        } catch (InputMismatchException e) {
            System.out.println("Ошибка ввода. Введите целое число.");
            scanner.nextLine();
            return;
        }

        try {
            System.out.println("1.Завершить работу\n2.Сделать отметку о поломке");
            int m = 0;
            m = scanner.nextInt();
            if (m != 1 && m != 2) {
                System.out.println("Некорректный выбор. Введите 1 или 2.");
            }
            switch (m) {
                case 1:
                    break;
                case 2:
                    System.out.println("Пометка сделана");
                    break;
                default:
                    break;
            }
        }

        catch (InputMismatchException e) {
            System.out.println("Ошибка ввода.");
            scanner.nextLine();
        }
    }

    public void AddInfo(List<Car> cars) {
        int k = 0;
        boolean isValidInput = false;

        while (!isValidInput) {
            try {
                scanner.nextLine();
                System.out.println("Кол-во машин для создания: ");
                String input = scanner.nextLine();
                k = Integer.parseInt(input);

                if (k > 0) {
                    isValidInput = true;
                } else {
                    System.out.println("Ошибка ввода. Введите положительное целое число.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Ошибка ввода. Введите целое число.");
                scanner.nextLine();
            }
        }

        for (int i = 0; i < k; i++) {
            String brand = "";
            String model = "";
            int year = 0;
            isValidInput = false;

            while (!isValidInput) {
                System.out.println("Введите марку:");
                brand = scanner.nextLine();
                if (!brand.matches("[a-zA-Z]+")) {
                    System.out.println("Ошибка ввода. Марка должна содержать только буквы.");
                    continue;
                }
                System.out.println("Введите модель:");
                model = scanner.nextLine();
                if (!model.matches("[a-zA-Z]+")) {
                    System.out.println("Ошибка ввода. Модель должна содержать только буквы.");
                    continue;
                }

                System.out.println("Введите год:");
                String yearInput = scanner.nextLine();
                try {
                    year = Integer.parseInt(yearInput);
                    if (year <= 0) {
                        System.out.println("Ошибка ввода. Год должен быть положительным числом.");
                        continue;
                    }
                    isValidInput = true;
                } catch (NumberFormatException e) {
                    System.out.println("Ошибка ввода. Год должен быть числом.");
                }
            }

            System.out.println("Новый объект добавлен:");
            System.out.println("Марка: " + brand);
            System.out.println("Модель: " + model);
            System.out.println("Год: " + year);
            cars.add(new Car(brand, model, year));
        }
    }
}
