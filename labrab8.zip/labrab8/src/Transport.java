import java.util.Scanner;

abstract class Transport {
    public abstract void arenda();

    public String loginDisplay() {
        System.out.println("Введите марку и модель машины");
        Scanner in = new Scanner(System.in);
        String num1;
        try {
            num1 = in.nextLine();
            if (!num1.matches("[a-zA-Z\\s]+")) {
                throw new IllegalArgumentException("Ошибка ввода. Введите только буквы и пробелы.");
            }
        } catch (IllegalArgumentException e) {
            System.out.println(e.getMessage());
            num1 = loginDisplay();
        }
        return num1;
    }
}